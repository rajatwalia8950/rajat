<?php

return [
	'store' => [
		'myStore' => [
			'merchantId' => 'AYS326WRGPIIZ',
			'marketplaceId' => 'ATVPDKIKX0DER',
			'keyId' => 'AKIAIUNK5YXQVKNUKFTQ',
			'secretKey' => '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',
            'authToken' => '',
			'amazonServiceUrl' => 'https://mws.amazonservices.com/',
		]
	],

	// Default service URL
	'awsServiceUrl' => 'https://mws.amazonservices.com/',

	// Developer Secret Key
	'awsDeveloperKey' => 'xtumEyi0G/Z+F9ooCZeWOickpAVY6c90vnJ5q+kU',


	// Default time to pull records from amazon
	'awsDefaultPullTime' => '- 34520 hours',

	// Default time to pull records from amazon
	'awsMarketPlaceId' => 'ATVPDKIKX0DER',

	'awsPullOrderTypes' => array("Unshipped", "PartiallyShipped"),

	'muteLog' => false
];
