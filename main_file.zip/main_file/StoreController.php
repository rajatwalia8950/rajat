<?php

namespace App\Http\Controllers\API;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request; 
use App\Http\Controllers\Controller; 
use App\Models\User; 
use App\Models\Store;
use App\Models\StoreOrder;
use App\Models\StoreOrderItem;
use App\Models\UserDetails;
use App\Models\StoreSystem;
use App\Models\StoreOrderProcessor;
use Illuminate\Support\Facades\Auth; 
use Illuminate\Support\Facades\Config;
use Validator;
use URL;

/* Calling Marketplacetraits */
use App\Http\Services\Amazon;
use App\Http\Services\Ebay;

class StoreController extends Controller 
{

    use Amazon;
    use Ebay;

    /* check whether the seller credentials is correct */
    public function checkAccountStatus(Request $request){

        $data = $request->all();
        $storeIdentifier = $data['identifier'];
        $user = Auth::user();
        $userid = $user->id;
        /* cheking seller Id for amazon US credentials */
    
        if($storeIdentifier=='amazonus'){
            return $this->amusCheckAccountStatus($data);
        }
        
    }


    /**
     * saving store credentials for all stores
     *
     *@params array [$identifier , $othercredentials as needed per store wise]  
     *@return Boolean
     */
    public function saveCredentials(Request $request){
        $data = $request->all();
        $validator = Validator::make($request->all(), [ 
            'identifier' => 'required|',
            'storeName' => 'required'
        ]);

        $validator->after(function($validator) use ($data){
            //Check if store name already exist
            $store = Store::where('store_name','=',$data['storeName'])
                            ->where('owner_id','=',Auth::user()->id)
                            ->first();  
            if($store) {
                $validator->errors()->add('storeName', 'The Store is alredy registered with same name.'); 
            }                
        });     
            

        if ($validator->fails()) { 
              return response()->json(['error'=>$validator->errors()], Config::get('response-code.ERROR'));            
        }

        $storeIdentifier = $data['identifier'];
        $user = Auth::user();
        $userid = $user->id;

      
        /* saving amazon US credentials */
        if($storeIdentifier=='amazonus'){
            return $this->amusSaveStoreCredentials($data,$userid);
        }
        /* Saving Ebay US credentials */
        if($storeIdentifier=='ebayus'){
            return $this->eBaySaveStoreCredentials($data,$userid);
        }
    }


    /**
     * Getting all store list per User 
     *
     *@params none;  
     *@return json (all store information)
     */
    public function myStores(){

        $ownerId = Auth::user()->id;
        $queryStores = Store::query()->with('system');
      
        if(Auth::user()->role->slug == 'op') {
            $ownerId =  Auth::user()->created_by;
            $userId  =  Auth::user()->id;
            $queryStores->whereIn('id',function($query) use ($userId){
                                     $query->select('store_id')
                                           ->from(with(new StoreOrderProcessor)->getTable()) 
                                           ->where('processor_id','=', $userId)
                                           ->get();
             });
        }
       
        $queryStores->where('owner_id',$ownerId)->orderby('id','DESC');
        $stores =  $queryStores->paginate(Config::get('constant.pagination')); 
                                        
        if ($stores->isEmpty()) {
            return response()->json(['error'=>'No Stores available.'],  Config::get('response-code.ERROR'));
        }
        return response()->json(['success' => $stores],  Config::get('response-code.SUCCESS'));
    }


    /**
     * pulling orders from the vendor websites
     *
     *@params varchar $slug of store;  
     *@return json [Boolenan ]
     */
    public function syncStores(Request $request){
        $data = $request->all(); 
        $slug = $data['slug'];
        $returnValue = [];
        $storeInfo = Store::with('system')->whereSlug($slug)->first();
        /* 1 is the store systemid of amazon US */
        if($storeInfo->system->id == 1){        
            $returnValue = $this->amusGetamazonorders($storeInfo->id);
            
        }elseif($storeInfo->system->id == 2){
            $returnValue = $this->ebayGetEbayOrders($storeInfo->id);
        }
        return response()->json($returnValue);
    }

    //search store 
    /*
    * @param search keyword [string]
    * @return list of stores 
    */
    public function search(Request $request) {
        $input = $request->all();
     
        $queryStores = Store::query();
        $queryStores->with('system');
        $queryStores->where('owner_id', Auth::user()->id);

        if(!empty($input['keyword'])) {
            $queryStores->where('store_name','like','%'.$input['keyword'].'%');                 
        }
        $stores = $queryStores->paginate(Config::get('constant.pagination')); 

        if ($stores->isEmpty()) {
            return response()->json(['error'=>'No Stores available.'],  Config::get('response-code.ERROR'));
        }

        return response()->json(['success' => $stores],  Config::get('response-code.SUCCESS'));
    }
    
}


